package com.elaparato;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ElaparatoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ElaparatoApplication.class, args);
	}

}
