package com.elaparato;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ElaparatoApplicationTests {

	@Test
	void contextLoads() {
	}

}
